SerialPortConnection
====================

文章《[用C#一步步写串口通信](http://blog.csdn.net/geekwangminli/article/details/7851673)》的代码，点击右下方的“Download Zip”下载
